<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Basude It Solution</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="fontawesome/css/fontawesome.min.css">
	<link rel="stylesheet" type="text/css" href="fontawesome/css/all.css">
	<script type="text/javascript" src="fontawesome/js/fontawesome.min.js"></script>
	<script type="text/javascript" src="fontawesome/js/all.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css">

	 <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
   
</head>
<body>
<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" style="box-shadow: none;">
      <span class="text-primary"><i class="fa-solid fa-bars" style="font-size: 20pt;"></i></span>
    </button>
    <a class="navbar-brand" href="index.html"><img src="logo.jpg"></a>
    <div style="float: left;">
    	 <form class="d-flex mt-3" role="search">
          <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
          <button class="btn btn-outline-primary" type="submit" style="width:45vh;">Search</button>
        </form>
    </div>
	 </div>
  </div>
</nav>
<nav class="navbar navbar-expand-lg bg-body-tertiary">
	<div class="container-fluid">
		<div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
      <div class="offcanvas-header">
        <img src="logo.jpg">
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
      </div>
      <div class="offcanvas-body">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#">Home</a>
          </li>
          
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Products
            </a>
            <ul class="dropdown-menu">
             <!-- php to show category -->
               <?php
						      include_once "Simple_Admin_Panel_In_PHP_With_Source_code/admin_panel/config/dbconnect.php";
						      $sql="SELECT * from category";
						      $result=$conn-> query($sql);
						      $count=1;
						      if ($result-> num_rows > 0){
						        while ($row=$result-> fetch_assoc()) {
						    ?>
						   <li><a class="dropdown-item" href="#"><?=$row["category_name"]?></a></li>
						 <?php }} ?>
            </ul>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Contact</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Services</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">My Recycle</a>
          </li>
        </ul>
        
        <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#"><span style="margin-right: 10px;"><i class="fa-solid fa-user"></i></span>Login</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#"><span style="margin-right: 10px;"><i class="fa-solid fa-shopping-cart"></i></span>Cart</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#"><span style="margin-right: 10px;"><i class="fa-solid fa-phone"></i></span>+91 9876543210</a>
          </li>
        </ul>
      </div>
	</div>
</nav>
<!-- header -->
<!-- <div id="header">
	<div class="container">
		<div class="row">
			<div class="col-md-3 col-lg-3">
				<h1 class="display-4" style="padding-top: 25vh;"><i>Professional <br>IT Solution</i></h1>
				<p style="padding-bottom: 25vh;">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore  </p><br>
				
			</div>
		</div>
	</div>
</div> -->
<div id="carouselExampleCaptions" class="carousel slide">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
    
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active text-center">
      <img src="log-in-girl.svg" class="d-block" style="max-width: 36%; float: center;" alt="...">
      <div class="carousel-caption d-md-block">
        <h5 class="display-1 text-dark">Your Perfect Pc is Here</h5>
        
      </div>
    </div>
    <div class="carousel-item">
      <img src="girl.svg" class="d-block" style="max-width: 47%; float: center;" alt="...">
      <div class="carousel-caption d-md-block">
        <h5 class="display-1 text-dark"><span style="color: #0d6efd;">Extreme</span> Deals of The Day</h5>
        
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div><br>


<!-- categories -->


<div class="container">
	<div class="row">
		<div class="col-lg-4 col-md-4">
			<div class="card crsr">
				<img src="mac.jpg" style="object-fit: contain; width: 100%; float: center;">
			</div><br>
		</div>
		<div class="col-lg-4 col-md-4">
			<div class="card crsr">
				<img src="laptop1.jpg">
			</div><br>
		</div>
		<div class="col-lg-4 col-md-4">
			<div class="card crsr">
				<img src="desktop.jpg">
			</div><br>
		</div>
	</div>
</div>


<!-- end -->

<!-- products -->
		<div class="container">
				<h3>Featured Products</h3><div style="border-bottom: 1px solid #0d6efd; width: 20%;"></div><br>
			
			<div class="container conte" style="background-color: white;">
				 <div class="slider owl-carousel">
				 	<?php
			      include_once "Simple_Admin_Panel_In_PHP_With_Source_code/admin_panel/config/dbconnect.php";
			      $sql="SELECT * from product, category WHERE product.category_id=category.category_id";
			      $result=$conn-> query($sql);
			      $count=1;
			      if ($result-> num_rows > 0){
			        while ($row=$result-> fetch_assoc()) {
			    ?>
	         <a href="#" style="text-decoration: none; color: black;"><div class="car">
	            <div class="container conte">
	            	<div class="img">
	               <img src="Simple_Admin_Panel_In_PHP_With_Source_code/admin_panel/<?=$row["product_image"]?>" alt="" style="object-fit: contain; width: 100%; height: 35vh; float: center;">
	            </div>
	            <div class="content">
	               <div class="title">
	                  <h3><?=$row["product_name"]?></h3>
	               </div>
	               <p><del>₹ Old Price</del><b> ₹ <?=$row["price"]?></b></p>
	            </div>
	            </div>
	         </div></a>
	       <?php }} ?>
	       </div><br><br>
	       
			</div>

			<!-- new product -->

			<!-- products -->
			<h3>New Products</h3><div style="border-bottom: 1px solid #0d6efd; width: 15%;"></div><br>
			<!-- product slider -->
			<div class="container conte">
				 <div class="slider owl-carousel">
				 	<?php
			      include_once "Simple_Admin_Panel_In_PHP_With_Source_code/admin_panel/config/dbconnect.php";
			      $sql="SELECT * from product, category WHERE product.category_id=category.category_id";
			      $result=$conn-> query($sql);
			      $count=1;
			      if ($result-> num_rows > 0){
			        while ($row=$result-> fetch_assoc()) {
			    ?>
	         <a href="#" style="text-decoration: none; color: black;"><div class="car">
	            <div class="container conte">
	            	<div class="img">
	               <img src="Simple_Admin_Panel_In_PHP_With_Source_code/admin_panel/<?=$row["product_image"]?>" alt="" style="object-fit: contain; width: 100%; height: 35vh; float: center;">
	            </div>
	            <div class="content">
	               <div class="title">
	                  <h3><?=$row["product_name"]?></h3>
	               </div>
	               <div class="sub-title">
	                  Graphic Designer
	               </div>
	               <p><del>₹ Old Price</del><b> ₹ <?=$row["price"]?></b></p>
	            </div>
	            </div>
	         </div></a>
	       <?php }} ?>
	       </div><br><br>
	       <script type="text/javascript">
	       	$('.slider').owlCarousel({
				    loop:true,
				    margin:10,
				    responsiveClass:true,
				    autoplay: true,
				    autoplayTimeout: 2000, //2000ms = 2s;
				    responsive:{
				        0:{
				            items:1,
				            nav:false
				        },
				        600:{
				            items:3,
				            nav:false
				        },
				        1000:{
				            items:4,
				            nav:false,
				            loop:true
				        }
    }
})
	       </script>
			</div>
		</div>
<!-- end product -->
	<div style="background-color: #0d6efd; padding: 5%; height: 55vh;">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-lg-6">
					<h2 class="display-5 text-light"><b>Our Services</b></h2>
					<p class="text-light" style="font-size: 16pt;">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt</p><br><br>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4 col-lg-4">
					<div class="card" style="padding: 5%; border-radius: 0;box-shadow: 10px 10px #f2f2f2;">
						<p style="color: #0d6efd; font-size: 26pt; line-height: 95%;">Cloud <br>Solution</p>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo</p>
						<a href="" style="text-decoration: none;">+ Learn More</a>
					</div><br>
				</div>

				<div class="col-md-4 col-lg-4">
					<div class="card" style="padding: 5%; border-radius: 0;box-shadow: 10px 10px #f2f2f2;">
						<p style="color: #0d6efd; font-size: 26pt; line-height: 95%;">Managed IT<br>Services</p>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo</p>
						<a href="" style="text-decoration: none;">+ Learn More</a>
					</div><br>
				</div>

				<div class="col-md-4 col-lg-4">
					<div class="card" style="padding: 5%; border-radius: 0;box-shadow: 10px 10px #f2f2f2;">
						<p style="color: #0d6efd; font-size: 26pt; line-height: 95%;">Disaster <br>Recovery</p>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo</p>
						<a href="" style="text-decoration: none;">+ Learn More</a>
					</div><br>
				</div>

				<div class="col-md-4 col-lg-4">
					<div class="card" style="padding: 5%; border-radius: 0;box-shadow: 10px 10px #f2f2f2;">
						<p style="color: #0d6efd; font-size: 26pt; line-height: 95%;">Cloud <br>Desktop</p>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo</p>
						<a href="" style="text-decoration: none;">+ Learn More</a>
					</div><br>
				</div>

				<div class="col-md-4 col-lg-4">
					<div class="card" style="padding: 5%; border-radius: 0;box-shadow: 10px 10px #f2f2f2;">
						<p style="color: #0d6efd; font-size: 26pt; line-height: 95%;">Network <br>Solutions</p>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo</p>
						<a href="" style="text-decoration: none;">+ Learn More</a>
					</div><br>
				</div>

				<div class="col-md-4 col-lg-4">
					<div class="card" style="padding: 5%; border-radius: 0;box-shadow: 10px 10px #f2f2f2;">
						<p style="color: #0d6efd; font-size: 26pt; line-height: 95%;">Support <br>Consulting</p>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo</p>
						<a href="" style="text-decoration: none;">+ Learn More</a>
					</div><br>
				</div>
			</div><br>
		</div><br>

				

        <div class="container">
        	<div class="row">
			<div class="col-md-4 col-lg-4">
				<div class="container">
					<div class="row">
						<div class="col-md-4 col-lg-4">
							<span><script src="https://cdn.lordicon.com/ritcuqlt.js"></script>
								<lord-icon
								    src="https://cdn.lordicon.com/hgvwxhhl.json"
								    trigger="loop"
								    colors="primary:#4be1ec,secondary:#cb5eee"
								    state="loop"
								    style="height: 120px; width: 120px;">
								</lord-icon></span>
						</div>
						<div class="col-md-8 col-lg-8">
							<h3>Free Shipping</h3>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua.</p>
						</div>
					</div>
				</div>
			</div>

			<div class="col-md-4 col-lg-4">
				<div class="container">
					<div class="row">
						<div class="col-md-4 col-lg-4">
							<span><script src="https://cdn.lordicon.com/ritcuqlt.js"></script>
									<lord-icon
									    src="https://cdn.lordicon.com/uutnmngi.json"
									    trigger="loop"
									    colors="primary:#4be1ec,secondary:#cb5eee"
									    state="loop"
									    style="width:120px;height:120px;">
									</lord-icon></span>
						</div>
						<div class="col-md-8 col-lg-8">
							<h3>Return & Exchange</h3>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua.</p>
						</div>
					</div>
				</div>
			</div>

			<div class="col-md-4 col-lg-4">
				<div class="container">
					<div class="row">
						<div class="col-md-4 col-lg-4">
							<span><script src="https://cdn.lordicon.com/ritcuqlt.js"></script>
									<lord-icon
									    src="https://cdn.lordicon.com/efdhjqgx.json"
									    trigger="loop"
									    style="width:120px;height:120px;">
									</lord-icon></span>
						</div>
						<div class="col-md-8 col-lg-8">
							<h3>Satisfaction Guarantee</h3>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua.</p>
						</div>
					</div>
				</div>
			</div>
		</div><br>
  </div>

  <!-- footer -->




</body>
</html>


