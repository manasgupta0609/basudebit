<?php
function get_settings() {
  return [
    'theme' => 'default',
  ];
}
