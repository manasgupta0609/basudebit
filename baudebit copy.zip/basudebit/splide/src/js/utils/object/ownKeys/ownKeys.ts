/**
 * An alias of `Object.keys()`
 */
export const ownKeys = Object.keys;